package com.saathi.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.text.Normalizer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Saathi ka dil: message padhkar sunata hai, bolkar jawab sunta hai,
 * "bhejun?" puchta hai, aur haan kehne par WhatsApp ke reply se bhej deta hai.
 */
public class SaathiService extends Service implements TextToSpeech.OnInitListener {

    /** Ek aaya hua message. */
    static class Msg {
        final String who;
        final String text;
        final Notification.Action action;
        final RemoteInput input;

        Msg(String who, String text, Notification.Action action, RemoteInput input) {
            this.who = who;
            this.text = text;
            this.action = action;
            this.input = input;
        }
    }

    private enum Stage { IDLE, ASK, CONFIRM }

    static volatile SaathiService instance;
    static volatile String lastSentText;
    static volatile long lastSentTime;

    private static final String CHANNEL = "saathi";

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ArrayDeque<Msg> queue = new ArrayDeque<>();

    private TextToSpeech tts;
    private boolean ttsReady = false;
    private SpeechRecognizer recognizer;

    private boolean busy = false;
    private Stage stage = Stage.IDLE;
    private Msg current;
    private String pendingReply;
    private int retries = 0;

    private static final Set<String> YES = words(
            "haan", "han", "ha", "haa", "yes", "yeah", "ok", "okay", "theek", "thik",
            "bhej", "bhejo", "send", "sahi", "हाँ", "हां", "हा", "भेज", "भेजो", "ठीक", "सही", "जी");
    private static final Set<String> NO = words(
            "nahi", "nahin", "na", "no", "nope", "cancel", "skip", "chhodo", "chodo", "mat", "rehne",
            "नहीं", "नही", "ना", "न", "छोड़ो", "छोड़", "रहने", "मत", "कैंसिल");

    private static Set<String> words(String... w) {
        HashSet<String> s = new HashSet<>();
        for (String x : w) s.add(Normalizer.normalize(x, Normalizer.Form.NFC));
        return s;
    }

    private static boolean hasAny(String heard, Set<String> set) {
        String t = Normalizer.normalize(heard.toLowerCase(Locale.ROOT), Normalizer.Form.NFC);
        for (String tok : t.split("[\\s,.!?।]+")) {
            if (set.contains(tok)) return true;
        }
        return false;
    }

    /** NotifListener yahan se message deta hai. */
    static void deliver(final Msg m) {
        final SaathiService s = instance;
        if (s == null) return;
        s.main.post(new Runnable() {
            @Override
            public void run() {
                s.add(m);
            }
        });
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        goForeground();
        tts = new TextToSpeech(this, this);
    }

    private void goForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(
                new NotificationChannel(CHANNEL, "Saathi", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Saathi chalu hai")
                .setContentText("WhatsApp ke message bolkar sunane ke liye taiyaar")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build();
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(1, n);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        instance = null;
        if (recognizer != null) {
            recognizer.destroy();
            recognizer = null;
        }
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        super.onDestroy();
    }

    // ---------- bolna ----------

    @Override
    public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS) return;
        int r = tts.setLanguage(new Locale("hi", "IN"));
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale.getDefault());
        }
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {
            }

            @Override
            public void onDone(String utteranceId) {
                spoken(utteranceId);
            }

            @Override
            public void onError(String utteranceId) {
                spoken(utteranceId);
            }
        });
        ttsReady = true;
        say("Saathi chalu ho gaya.", "start");
    }

    private void say(String text, String id) {
        if (tts == null || !ttsReady) return;
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id);
    }

    private void spoken(final String id) {
        main.post(new Runnable() {
            @Override
            public void run() {
                afterSpeech(id);
            }
        });
    }

    private void afterSpeech(String id) {
        if ("ask".equals(id) || "confirm".equals(id) || "retry".equals(id) || "confirm_again".equals(id)) {
            listen();
        } else if ("info".equals(id) || "skip".equals(id) || "done".equals(id)) {
            next();
        } else if ("start".equals(id)) {
            if (!busy && !queue.isEmpty()) next();
        }
    }

    // ---------- message ka kram ----------

    private void add(Msg m) {
        queue.add(m);
        if (!busy && ttsReady) next();
    }

    private void next() {
        current = queue.poll();
        if (current == null) {
            busy = false;
            stage = Stage.IDLE;
            return;
        }
        busy = true;
        retries = 0;
        String body = current.text.length() > 300 ? current.text.substring(0, 300) : current.text;
        if (current.action == null || current.input == null) {
            stage = Stage.IDLE;
            say(current.who + " ka message. " + body, "info");
        } else {
            stage = Stage.ASK;
            say(current.who + " ka message. " + body + ". Jawab dena hai toh bolo. Nahi dena toh bolo chhodo.", "ask");
        }
    }

    // ---------- sunna ----------

    private void listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Is phone mein bolkar likhne ki suvidha nahi mili.", "skip");
            return;
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override
                public void onReadyForSpeech(Bundle params) {
                }

                @Override
                public void onBeginningOfSpeech() {
                }

                @Override
                public void onRmsChanged(float rmsdB) {
                }

                @Override
                public void onBufferReceived(byte[] buffer) {
                }

                @Override
                public void onEndOfSpeech() {
                }

                @Override
                public void onError(int error) {
                    main.post(new Runnable() {
                        @Override
                        public void run() {
                            heardNothing();
                        }
                    });
                }

                @Override
                public void onResults(Bundle results) {
                    ArrayList<String> list =
                            results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    final String heard = (list == null || list.isEmpty()) ? "" : list.get(0);
                    main.post(new Runnable() {
                        @Override
                        public void run() {
                            if (heard.trim().isEmpty()) heardNothing();
                            else handleHeard(heard);
                        }
                    });
                }

                @Override
                public void onPartialResults(Bundle partialResults) {
                }

                @Override
                public void onEvent(int eventType, Bundle params) {
                }
            });
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        recognizer.startListening(i);
    }

    private void heardNothing() {
        if (stage == Stage.IDLE) return;
        if (retries < 1) {
            retries++;
            say("Sunai nahi diya. Dobara bolo.", stage == Stage.CONFIRM ? "confirm_again" : "retry");
        } else {
            say("Theek hai, chhod diya.", "skip");
        }
    }

    private void handleHeard(String heard) {
        if (stage == Stage.ASK) {
            if (hasAny(heard, NO)) {
                say("Theek hai, chhod diya.", "skip");
                return;
            }
            pendingReply = heard.trim();
            stage = Stage.CONFIRM;
            retries = 0;
            say("Main ye bhejunga: " + pendingReply + ". Bhejun? Haan ya na bolo.", "confirm");
        } else if (stage == Stage.CONFIRM) {
            if (hasAny(heard, NO)) {
                say("Theek hai, nahi bheja.", "skip");
            } else if (hasAny(heard, YES)) {
                if (sendReply(pendingReply)) say("Bhej diya.", "done");
                else say("Bhej nahi paya.", "skip");
            } else {
                heardNothing();
            }
        }
    }

    // ---------- jawab bhejna ----------

    private boolean sendReply(String reply) {
        if (current == null || current.action == null || current.input == null || reply == null) {
            return false;
        }
        try {
            Intent i = new Intent();
            Bundle b = new Bundle();
            b.putCharSequence(current.input.getResultKey(), reply);
            RemoteInput.addResultsToIntent(new RemoteInput[]{current.input}, i, b);
            lastSentText = reply;
            lastSentTime = System.currentTimeMillis();
            current.action.actionIntent.send(this, 0, i);
            return true;
        } catch (PendingIntent.CanceledException e) {
            return false;
        }
    }
}
