package com.saathi.app;

import android.app.Notification;
import android.app.RemoteInput;
import android.os.Bundle;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.HashMap;

/** WhatsApp ke notification dekhta hai aur SaathiService ko bhejta hai. */
public class NotifListener extends NotificationListenerService {

    private final HashMap<String, String> seen = new HashMap<>();

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            handle(sbn);
        } catch (Exception ignored) {
            // koi galti ho toh app band na ho
        }
    }

    private void handle(StatusBarNotification sbn) {
        String pkg = sbn.getPackageName();
        if (!"com.whatsapp".equals(pkg) && !"com.whatsapp.w4b".equals(pkg)) return;

        Notification n = sbn.getNotification();
        if (n == null) return;
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        if ((n.flags & Notification.FLAG_ONGOING_EVENT) != 0) return;
        if (Notification.CATEGORY_CALL.equals(n.category)) return;

        Bundle ex = n.extras;
        if (ex == null) return;

        CharSequence title = ex.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence text = ex.getCharSequence(Notification.EXTRA_TEXT);
        CharSequence sender = null;

        Parcelable[] msgs = ex.getParcelableArray(Notification.EXTRA_MESSAGES);
        if (msgs != null && msgs.length > 0 && msgs[msgs.length - 1] instanceof Bundle) {
            Bundle last = (Bundle) msgs[msgs.length - 1];
            CharSequence t = last.getCharSequence("text");
            if (t != null) text = t;
            sender = last.getCharSequence("sender");
        }

        if (text == null || text.toString().trim().isEmpty()) return;
        String textStr = text.toString();

        // apna bheja hua jawab dobara na sunaye
        String sent = SaathiService.lastSentText;
        if (sent != null && sent.equals(textStr)
                && System.currentTimeMillis() - SaathiService.lastSentTime < 90000) {
            return;
        }

        // ek hi message dobara na bole
        String key = sbn.getKey();
        if (textStr.equals(seen.get(key))) return;
        if (seen.size() > 200) seen.clear();
        seen.put(key, textStr);

        String who;
        if (sender != null && title != null && !sender.toString().equals(title.toString())) {
            who = sender + " (" + title + ")";
        } else if (sender != null) {
            who = sender.toString();
        } else if (title != null) {
            who = title.toString();
        } else {
            who = "Koi";
        }

        Notification.Action replyAction = null;
        RemoteInput replyInput = null;
        if (n.actions != null) {
            for (Notification.Action a : n.actions) {
                RemoteInput[] ris = a.getRemoteInputs();
                if (ris != null && ris.length > 0) {
                    replyAction = a;
                    replyInput = ris[0];
                    break;
                }
            }
        }

        SaathiService.deliver(new SaathiService.Msg(who, textStr, replyAction, replyInput));
    }
}
