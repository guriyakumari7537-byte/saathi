package com.saathi.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Seedha-saada screen: teen button, ek ek karke dabao. */
public class MainActivity extends Activity {

    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = dp(20);
        box.setPadding(p, p, p, p);
        scroll.addView(box);

        box.addView(label("Saathi", 34));
        status = label("", 20);
        box.addView(status);

        box.addView(button("1. Mic ki ijazat do", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(new String[]{
                            Manifest.permission.RECORD_AUDIO,
                            Manifest.permission.POST_NOTIFICATIONS}, 1);
                } else {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
                }
            }
        }));

        box.addView(button("2. Notification access do", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            }
        }));

        box.addView(button("3. Saathi chalu karo", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                        != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(MainActivity.this, "Pehle mic ki ijazat do", Toast.LENGTH_LONG).show();
                    return;
                }
                startForegroundService(new Intent(MainActivity.this, SaathiService.class));
                v.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        refresh();
                    }
                }, 800);
            }
        }));

        box.addView(button("Saathi band karo", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService(new Intent(MainActivity.this, SaathiService.class));
                v.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        refresh();
                    }
                }, 500);
            }
        }));

        box.addView(label(
                "Agar 'Notification access' wala option grey dikhe: phone ki Settings > Apps > Saathi "
                        + "kholo, upar teen bindu dabao, 'Restricted settings allow karo' chuno, "
                        + "phir dobara try karo.", 16));

        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        refresh();
    }

    private void refresh() {
        boolean mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED;
        String enabled = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        boolean notif = enabled != null && enabled.contains(getPackageName());
        boolean running = SaathiService.instance != null;
        status.setText("1. Mic ijazat: " + (mic ? "HAAN" : "NAHI")
                + "\n2. Notification access: " + (notif ? "HAAN" : "NAHI")
                + "\n3. Saathi: " + (running ? "CHALU" : "BAND"));
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private TextView label(String text, int sp) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setPadding(0, dp(10), 0, dp(10));
        return t;
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(20);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }
}
